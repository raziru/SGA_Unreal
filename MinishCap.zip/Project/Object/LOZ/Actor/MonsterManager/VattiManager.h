#pragma once
class VattiManager:public MonsterManager
{
public:
	VattiManager();
	~VattiManager();

private:

};



