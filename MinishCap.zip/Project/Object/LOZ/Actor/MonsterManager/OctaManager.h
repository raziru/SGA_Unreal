#pragma once
class OctaManager:public MonsterManager
{
public:
	OctaManager(UINT red, UINT blue ,UINT yellow);
	~OctaManager();

private:

};

