#pragma once
class BlueOcta:public Octa
{
	
public:
	BlueOcta();
	~BlueOcta();
	
	void AddAction() override;
private:


};



