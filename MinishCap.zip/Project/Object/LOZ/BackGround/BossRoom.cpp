#include "Framework.h"
#include "BossRoom.h"

BossRoom::BossRoom()
{
}
