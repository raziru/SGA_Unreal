#include "Framework.h"
#include "BackGround.h"

BackGround::BackGround()
{
	
}

BackGround::~BackGround()
{
}



void BackGround::AddAction()
{
}

