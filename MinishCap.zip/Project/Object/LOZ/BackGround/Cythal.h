#pragma once
class Cythal:public BackGround
{
public:
	Cythal();
	~Cythal();


	virtual void Update() override;
	virtual void Render() override;
	void AddAction() override;
private:


	
};


