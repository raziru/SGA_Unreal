#pragma once
class TransparentTile:public Tile
{
public:
	TransparentTile();
	~TransparentTile();

	void AddAction();
private:
	wstring file2;
	wstring file3;



};



