#pragma once
class Map
{
public:
	Map();
	~Map();

private:
	wstring file;
	
};



