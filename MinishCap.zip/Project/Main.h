#pragma once

#include "__Others/resource.h"
